﻿Imports System.IO

Public Class Form1
   Dim pos As Integer
    Dim key As String
    Dim CaseSensitive As CompareMethod


   Private Sub btnOpenFile_Click(sender As Object, e As EventArgs) Handles btnOpenFile.Click
      Dim DlgOpenFile As New OpenFileDialog()
      Dim fileName As String
      DlgOpenFile.InitialDirectory = "C:\temp;"
      DlgOpenFile.Filter = "All files (*.*)| *.* |VB files (*.vb)|*.vb"
      DlgOpenFile.FilterIndex = 2

      If DlgOpenFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
         fileName = DlgOpenFile.FileName
         txtFile.Text = File.ReadAllText(fileName)
         btnSearch.Focus()
      Else
         MessageBox.Show("No file selected!", "Lab 3", MessageBoxButtons.OK, MessageBoxIcon.Information)

      End If
   End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        txtSearchTarget.Text = ""
        key = InputBox("Enter a string: " & vbCrLf & "CS234 - Lab3", "Search Target", "")
        If key = "" Then
            MessageBox.Show("No target entered!", "Lab 3", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
        txtSearchTarget.Text = key
        pos = InStr(txtFile.Text, key, CaseSensitive)
        If pos > 0 Then
            txtFile.SelectionStart = pos - 1
            txtFile.SelectionLength = key.Length
            txtFile.ScrollToCaret()
            txtFile.Focus()
            btnNext.Enabled = True

        Else
            MessageBox.Show("Target not found!", "Lab 3", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End If

    End Sub

   Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
      Dim result1 As DialogResult = MessageBox.Show("Do you really want to exit?", _
                                                    "Lab 3", _
                                                    MessageBoxButtons.YesNo, MessageBoxIcon.Information)
      If result1 = Windows.Forms.DialogResult.Yes Then
         Me.Close()
      End If

   End Sub

   Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        pos = InStr(pos + 1, txtFile.Text, key, CaseSensitive)
      If pos > 0 Then
         txtFile.SelectionStart = pos - 1
         txtFile.SelectionLength = key.Length
         txtFile.Focus()
      Else
         MessageBox.Show("End of file reached!", "Lab 3", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
         btnNext.Enabled = False
      End If
   End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtSearchTarget.Text = ""

    End Sub

    Private Sub rdoYes_CheckedChanged(sender As Object, e As EventArgs) Handles rdoYes.CheckedChanged
        If rdoYes.Checked Then
            CaseSensitive = CompareMethod.Binary
        Else
            CaseSensitive = CompareMethod.Text
        End If
    End Sub
End Class
