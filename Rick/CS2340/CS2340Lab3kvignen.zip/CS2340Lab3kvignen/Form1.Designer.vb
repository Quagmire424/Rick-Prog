﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnOpenFile = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtFile = New System.Windows.Forms.TextBox()
        Me.txtSearchTarget = New System.Windows.Forms.TextBox()
        Me.lblSearchTarget = New System.Windows.Forms.Label()
        Me.rdoYes = New System.Windows.Forms.RadioButton()
        Me.rdoNo = New System.Windows.Forms.RadioButton()
        Me.lblCaseSensitive = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnOpenFile
        '
        Me.btnOpenFile.Location = New System.Drawing.Point(56, 341)
        Me.btnOpenFile.Name = "btnOpenFile"
        Me.btnOpenFile.Size = New System.Drawing.Size(75, 23)
        Me.btnOpenFile.TabIndex = 0
        Me.btnOpenFile.Text = "&OPEN FILE"
        Me.btnOpenFile.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(163, 341)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnSearch.TabIndex = 1
        Me.btnSearch.Text = "&SEARCH"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Enabled = False
        Me.btnNext.Location = New System.Drawing.Point(296, 341)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 2
        Me.btnNext.Text = "&NEXT"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(444, 341)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "E&XIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtFile
        '
        Me.txtFile.Location = New System.Drawing.Point(90, 89)
        Me.txtFile.Multiline = True
        Me.txtFile.Name = "txtFile"
        Me.txtFile.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtFile.Size = New System.Drawing.Size(450, 230)
        Me.txtFile.TabIndex = 4
        Me.txtFile.TabStop = False
        Me.txtFile.WordWrap = False
        '
        'txtSearchTarget
        '
        Me.txtSearchTarget.BackColor = System.Drawing.SystemColors.Window
        Me.txtSearchTarget.Location = New System.Drawing.Point(90, 39)
        Me.txtSearchTarget.Name = "txtSearchTarget"
        Me.txtSearchTarget.ReadOnly = True
        Me.txtSearchTarget.Size = New System.Drawing.Size(210, 20)
        Me.txtSearchTarget.TabIndex = 5
        Me.txtSearchTarget.TabStop = False
        '
        'lblSearchTarget
        '
        Me.lblSearchTarget.AutoSize = True
        Me.lblSearchTarget.Location = New System.Drawing.Point(160, 23)
        Me.lblSearchTarget.Name = "lblSearchTarget"
        Me.lblSearchTarget.Size = New System.Drawing.Size(75, 13)
        Me.lblSearchTarget.TabIndex = 6
        Me.lblSearchTarget.Text = "Search Target"
        '
        'rdoYes
        '
        Me.rdoYes.AutoSize = True
        Me.rdoYes.Checked = True
        Me.rdoYes.Location = New System.Drawing.Point(394, 39)
        Me.rdoYes.Name = "rdoYes"
        Me.rdoYes.Size = New System.Drawing.Size(43, 17)
        Me.rdoYes.TabIndex = 4
        Me.rdoYes.TabStop = True
        Me.rdoYes.Text = "Yes"
        Me.rdoYes.UseVisualStyleBackColor = True
        '
        'rdoNo
        '
        Me.rdoNo.AutoSize = True
        Me.rdoNo.Location = New System.Drawing.Point(394, 63)
        Me.rdoNo.Name = "rdoNo"
        Me.rdoNo.Size = New System.Drawing.Size(39, 17)
        Me.rdoNo.TabIndex = 5
        Me.rdoNo.Text = "No"
        Me.rdoNo.UseVisualStyleBackColor = True
        '
        'lblCaseSensitive
        '
        Me.lblCaseSensitive.AutoSize = True
        Me.lblCaseSensitive.Location = New System.Drawing.Point(394, 20)
        Me.lblCaseSensitive.Name = "lblCaseSensitive"
        Me.lblCaseSensitive.Size = New System.Drawing.Size(77, 13)
        Me.lblCaseSensitive.TabIndex = 9
        Me.lblCaseSensitive.Text = "Case Sensitive"
        '
        'Form1
        '
        Me.AcceptButton = Me.btnOpenFile
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(630, 407)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblCaseSensitive)
        Me.Controls.Add(Me.rdoNo)
        Me.Controls.Add(Me.rdoYes)
        Me.Controls.Add(Me.lblSearchTarget)
        Me.Controls.Add(Me.txtSearchTarget)
        Me.Controls.Add(Me.txtFile)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.btnOpenFile)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Lab3kvignen"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnOpenFile As System.Windows.Forms.Button
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Friend WithEvents txtSearchTarget As System.Windows.Forms.TextBox
    Friend WithEvents lblSearchTarget As System.Windows.Forms.Label
    Friend WithEvents rdoYes As System.Windows.Forms.RadioButton
    Friend WithEvents rdoNo As System.Windows.Forms.RadioButton
    Friend WithEvents lblCaseSensitive As System.Windows.Forms.Label

End Class
