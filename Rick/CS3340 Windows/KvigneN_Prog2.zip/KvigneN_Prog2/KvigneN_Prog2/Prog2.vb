﻿Public Class Prog2

    Public Shared Sub Main()
        Application.Run(New FormClassHouse)
    End Sub
End Class
