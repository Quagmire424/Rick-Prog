﻿Public Class Prog3

   Public Shared Sub main()

      Application.Run(New Form1)

   End Sub
End Class
