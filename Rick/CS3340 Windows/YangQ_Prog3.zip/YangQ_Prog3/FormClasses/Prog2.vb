﻿Public Class Prog2

   Public Shared Sub main()
      Application.Run(New MyFormClass)
   End Sub
End Class
